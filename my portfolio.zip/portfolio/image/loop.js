let array=[];
let array1=['John','1',2,false];
let typeofNumber=[[1,2,3],[2,4,6],[-1,2]];
for(i=0;i<3;i++)
{
    for(j=0; j<typeofNumber[i].length;j++)
    {
        console.log(typeofNumber[i][j]);
    }
}